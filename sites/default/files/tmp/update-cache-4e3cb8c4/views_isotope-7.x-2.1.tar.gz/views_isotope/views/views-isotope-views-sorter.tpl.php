<?php
/**
 * @file
 * views-isotope-views-sorter.tpl.php
 *
 * @ingroup views_templates
 */
?>
<?php print $isotope_sorter; ?>
