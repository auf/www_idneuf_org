<?php
/**
 * @file
 * views-isotope-views-filter.tpl.php
 *
 * @ingroup views_templates
 */
?>
<?php print $isotope_filter; ?>
