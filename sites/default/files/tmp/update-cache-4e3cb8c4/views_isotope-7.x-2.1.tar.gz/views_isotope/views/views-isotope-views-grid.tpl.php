<?php
/**
 * @file
 * views-isotope-views-grid.tpl.php
 *
 * @ingroup views_templates
 */
?>
<?php print $isotope_grid; ?>
