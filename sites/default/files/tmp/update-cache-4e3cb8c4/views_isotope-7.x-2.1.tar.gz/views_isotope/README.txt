Views Isotope
-------------
Views Isotope implements the javascript isotope package by metafizzy.

Documentation: https://www.drupal.org/node/2586191

Installation Instructions: https://www.drupal.org/node/2634162
